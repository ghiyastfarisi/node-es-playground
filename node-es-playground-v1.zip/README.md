# node-es-playground
nodejs + aws elasticsearch playground
